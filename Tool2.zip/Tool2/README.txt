Tool2
=====

Tool2 evaluates 46 list entries covering 45 unique test sequences per view.
van-3 appears at the beginning and end of each list and is counted twice.
For equal weighting of distinct test sequences, use Tool1, as in our paper.

Quick start
-----------
Requires Python 3.9+ and NumPy. No GPU, model, images, or MATLAB required.
From this directory:

  python -m pip install -r requirements.txt
  python evaluate.py --results ../VL-UniTrack_UGVT_results

Extract the separately released VL-UniTrack_UGVT_results.zip first. Point
--results at the directory containing the 90 *_uav.txt / *_gro.txt files,
not at the ZIP or its parent. Nested predictions are also accepted:
UAV/<category>/<sequence>.txt and GRO/<category>/<sequence>.txt.
No duplicate prediction or GT file is needed for van-3.

Optional reference verification (only for the released VL-UniTrack results):

  python evaluate.py --results ../VL-UniTrack_UGVT_results --verify-reference

Optional machine-readable report and individual-view evaluation:

  python evaluate.py --results ../VL-UniTrack_UGVT_results --json metrics.json
  python evaluate.py --results ../VL-UniTrack_UGVT_results --view GRO

Existing report files are not overwritten. Paths to bundled GT and config
are resolved relative to evaluate.py, not the current working directory.

Expected metrics for the released final predictions
--------------------------------------------------
Tool1 gives 0.886 and 0.717 in UAV PR and SR, 0.853 and 0.704 in
ground-view PR and SR, and 0.869 and 0.711 in average PR and SR, respectively.

Tool2 gives 0.889 and 0.721 in UAV PR and SR, 0.856 and 0.709 in
ground-view PR and SR, and 0.872 and 0.715 in average PR and SR, respectively.
These values are rounded to three decimals; the program prints six decimals.

Our paper uses Tool1. It follows the standard equal-weight, sequence-averaged
evaluation convention: each distinct test sequence contributes once, without
additional weight from duplicate list entries. We recommend Tool1 for
comparisons. Both tools use identical GT, predictions, and metric definitions;
the score difference comes solely from counting van-3 twice in Tool2.
Use the same tool for all trackers being compared.

Metric definitions and file format
----------------------------------
* Rectangles are x, y, width, height in image pixels, one row per frame,
  in chronological order. Commas or whitespace are accepted. Coordinates
  are used as stored; no coordinate offset is added.
* PR is precision at center error <= 20 pixels, with centers computed as
  (x + (width-1)/2, y + (height-1)/2).
* SR is the mean success rate over 21 IoU thresholds 0, 0.05, ..., 1,
  using IoU > threshold and inclusive-coordinate overlap. It is sampled
  success-curve AUC, NOT SR at IoU=0.5 or trapezoidal AUC. Under this
  convention perfect predictions have SR=20/21, not 1.
* Curves are averaged equally over all 46 list entries, including both
  van-3 entries. They are not pooled over frames. Average is the arithmetic
  mean of the UAV and Ground scores, computed before display rounding.
* The first-frame prediction is replaced by GT for evaluation only.
  Later non-finite predictions or boxes with non-positive width/height
  are replaced with the preceding box, before first-frame replacement.
  Extra trailing predictions are truncated. Both repairs and truncation
  are reported. Missing/short files, malformed rectangles, or predictions
  still invalid after repair cause an error; no sequence is silently skipped.
* All bundled GT rows are finite and positive. The source toolkit's convention
  for non-positive GT rows is retained: overlap and center error are -1,
  and such rows remain in the denominator. It is not triggered by these GT.

Contents and provenance
-----------------------
This package is self-contained and does not need Tool1 installed.
evaluate.py: the same NumPy evaluator as Tool1, checked against the
existing UGVT evaluator and local MATLAB metric definitions in
calc_seq_err_robust.m, calc_rect_int.m, and eval_tracker.m.
config/: sequence lists and protocol/reference-metric metadata.
annos/: the same 90 original test-GT files as Tool1 (17,316 frames per view),
copied without modification. van-3 is reused, not duplicated on disk.
requirements.txt: runtime dependency.

No training GT, images, model weights, predictions, logs, or private paths
are included. GT originates from the UGVT dataset/toolkit; its ownership
and applicable dataset terms remain with the original providers. This
package does not grant a new GT license.

中文说明
--------
Tool2使用46条评测记录，覆盖45个不同测试序列；van-3在两个视角的
列表中都计入两次。公开结果在Tool2中得到平均PR为0.872、SR为0.715。
Tool1中每个独立序列只计入一次，符合等权的标准评测口径，避免重复
条目带来额外权重。本文采用Tool1，平均PR为0.869、SR为0.711，
并推荐使用Tool1进行方法比较。两者的GT和指标定义相同。
程序会实际读取预测框并计算指标，不会直接输出预设值。
--verify-reference仅用于核对单独发布的VL-UniTrack最终结果。
