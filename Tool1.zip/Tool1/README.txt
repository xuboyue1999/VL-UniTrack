Tool1
=====

Our paper uses Tool1. Each of the 45 paired test sequences is counted
once per view, following the standard equal-weight, sequence-averaged
evaluation convention. Tool1 is recommended for tracker comparisons.

Quick start
-----------
Requires Python 3.9+ and NumPy. No GPU, model, images, or MATLAB required.
From this directory:

  python -m pip install -r requirements.txt
  python evaluate.py --results ../VL-UniTrack_UGVT_results

Extract the separately released VL-UniTrack_UGVT_results.zip first. Point
--results at the directory containing the 90 *_uav.txt / *_gro.txt files,
not at the ZIP or its parent. The tool also accepts predictions organized
as UAV/<category>/<sequence>.txt and GRO/<category>/<sequence>.txt.

Optional reference verification (only for the released VL-UniTrack results):

  python evaluate.py --results ../VL-UniTrack_UGVT_results --verify-reference

Optional machine-readable report and individual-view evaluation:

  python evaluate.py --results ../VL-UniTrack_UGVT_results --json metrics.json
  python evaluate.py --results ../VL-UniTrack_UGVT_results --view UAV

Existing report files are not overwritten. Paths to bundled GT and config
are resolved relative to evaluate.py, not the current working directory.

Expected metrics for the released final predictions
--------------------------------------------------
Tool1 gives 0.886 and 0.717 in UAV PR and SR, 0.853 and 0.704 in
ground-view PR and SR, and 0.869 and 0.711 in average PR and SR, respectively.

Tool2 gives 0.889 and 0.721 in UAV PR and SR, 0.856 and 0.709 in
ground-view PR and SR, and 0.872 and 0.715 in average PR and SR, respectively.
These values are rounded to three decimals; the program prints six decimals.

Which tool should I use?
-----------------------
Tool1 gives each distinct test sequence equal weight and avoids additional
weight from duplicate list entries. We use Tool1 in our paper and recommend
it for comparisons. Tool2 uses 46 entries for the same 45 unique sequences;
van-3 appears at both the beginning and the end and is counted twice.
Both tools use identical GT, predictions, and metric definitions. The score
difference comes solely from this repeated weighting. Use the same tool
for all trackers being compared.

Metric definitions and file format
----------------------------------
* Rectangles are x, y, width, height in image pixels, one row per frame,
  in chronological order. Comma-separated or whitespace-separated TXT
  files are accepted. Coordinates are used as stored; no offset is added.
* PR is the fraction of center errors <= 20 pixels. Centers are computed
  as (x + (width-1)/2, y + (height-1)/2).
* SR is the arithmetic mean of the 21 success rates at IoU thresholds
  0, 0.05, ..., 1, using IoU > threshold. It is the toolkit's sampled
  success-curve AUC, NOT success rate at IoU=0.5 and NOT trapezoidal AUC.
  Inclusive-coordinate rectangle overlap is used, as in the local MATLAB
  toolkit. Consequently, even perfect predictions have SR=20/21 here.
* Rates are averaged equally over sequence-list entries, not pooled over
  frames. The final Average is the arithmetic mean of the two view scores.
  Averaging uses unrounded numbers; printed values are rounded afterwards.
* The first-frame prediction is replaced by GT for evaluation only.
  Invalid later predictions (non-finite values or non-positive width or
  height) are replaced with the preceding prediction, before the first-frame
  replacement. Extra trailing rows are truncated; both actions are reported.
  Missing files, short files, malformed rectangles, or invalid predictions
  remaining after repair cause an error rather than silently skipping data.
* All 34,632 bundled GT rows (17,316 per view) have finite, positive x/y/w/h.
  The evaluator retains the source toolkit's invalid-GT convention:
  a row with any non-positive GT coordinate has overlap and center error -1,
  and remains in the denominator. This convention is not triggered by these GT.

Contents and provenance
-----------------------
evaluate.py: standalone NumPy implementation, checked against the existing
UGVT evaluator and the local MATLAB toolkit's calc_seq_err_robust.m,
calc_rect_int.m, and eval_tracker.m metric definitions.
config/: sequence lists and protocol/reference-metric metadata.
annos/: exactly 90 original test-GT files, copied without changing values.
requirements.txt: runtime dependency.

No training GT, images, model weights, predictions, logs, or private paths
are included. Predictions are distributed separately. GT originates from
the UGVT dataset/toolkit; its ownership and applicable dataset terms remain
with the original providers. This package does not grant a new GT license.

中文说明
--------
Tool1评测45个不重复测试序列，每个序列只计入一次，符合每个独立序列
等权平均的标准评测口径，避免重复条目带来额外权重。本文采用Tool1，
并推荐用于方法比较，平均PR为0.869、SR为0.711。
Tool2使用包含46条记录的列表，仍然覆盖同样的45个不同序列，其中
van-3计入两次，平均PR为0.872、SR为0.715。两者的GT和指标定义相同。
以上数值对应单独发布的最终跟踪结果；评测其他结果时会重新计算。
--verify-reference仅用于核对这组公开结果，普通方法比较请不要添加。
