"""Standalone UGVT PR/SR evaluation; the adjacent config fixes the protocol."""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
OVERLAP_THRESHOLDS = np.arange(0.0, 1.0001, 0.05)
ERROR_THRESHOLDS = np.arange(0.0, 51.0, 1.0)


def load_rects(path: Path) -> np.ndarray:
    first = next((line for line in path.read_text().splitlines() if line.strip()), None)
    if first is None:
        raise ValueError(f"Empty rectangle file: {path}")
    rects = np.loadtxt(path, dtype=np.float64, delimiter="," if "," in first else None,
                       ndmin=2)
    if rects.shape[1] != 4:
        raise ValueError(f"Expected N x 4 (x, y, width, height) in {path}; got {rects.shape}")
    return rects


def find_result(results_dir: Path, name: str, view: str) -> Path:
    """Accept the released flat layout and view/category/sequence.txt layouts."""
    base = name.removesuffix(f"_{view.lower()}")
    category = base.split("-", 1)[0]
    candidates = (
        results_dir / f"{name}.txt",
        results_dir / view / category / f"{base}.txt",
        results_dir / view.lower() / category / f"{base}.txt",
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"Missing result for {name} under {results_dir}")


def repair_and_align(results: np.ndarray, anno: np.ndarray) -> tuple[np.ndarray, int, int]:
    if len(results) < len(anno):
        raise ValueError(f"Prediction has {len(results)} rows; GT requires {len(anno)}")
    trimmed = len(results) - len(anno)
    results = results[:len(anno)].copy()
    repaired = 0
    # Match the source toolkit: repair first, then set the initial box to GT.
    for index in range(1, len(anno)):
        rect = results[index]
        invalid = not np.isfinite(rect).all() or rect[2] <= 0 or rect[3] <= 0
        if invalid and not np.isnan(anno[index]).any():
            results[index] = results[index - 1]
            repaired += 1
    results[0] = anno[0]
    if not np.isfinite(results).all() or (results[:, 2:] <= 0).any():
        raise ValueError("Unusable prediction remains after previous-frame repair")
    return results, repaired, trimmed


def sequence_curves(results: np.ndarray, anno: np.ndarray) -> tuple[np.ndarray, np.ndarray, int, int]:
    results, repaired, trimmed = repair_and_align(results, anno)
    valid = (anno > 0).all(axis=1)
    overlap = np.full(len(anno), -1.0)
    a, b = results[valid], anno[valid]
    bottom_right_a = a[:, :2] + a[:, 2:] - 1
    bottom_right_b = b[:, :2] + b[:, 2:] - 1
    intersection_wh = np.maximum(
        0, np.minimum(bottom_right_a, bottom_right_b) - np.maximum(a[:, :2], b[:, :2]) + 1
    )
    intersection = intersection_wh.prod(axis=1)
    overlap[valid] = intersection / (a[:, 2:].prod(axis=1) + b[:, 2:].prod(axis=1) - intersection)
    centers_result = results[:, :2] + (results[:, 2:] - 1) / 2
    centers_gt = anno[:, :2] + (anno[:, 2:] - 1) / 2
    error = np.linalg.norm(centers_result - centers_gt, axis=1)
    # Historical toolkit compatibility. All bundled GT rows are valid (>0).
    error[~valid] = -1
    success = np.array([(overlap > t).mean() for t in OVERLAP_THRESHOLDS])
    precision = np.array([(error <= t).mean() for t in ERROR_THRESHOLDS])
    return success, precision, repaired, trimmed


def load_protocol(root: Path) -> tuple[dict, dict[str, list[str]]]:
    config = json.loads((root / "config" / "protocol.json").read_text())
    lists = {}
    for view in ("UAV", "GRO"):
        path = root / "config" / f"{view.lower()}_testing_set.txt"
        names = [s.strip() for s in path.read_text().splitlines() if s.strip()]
        if not all(re.fullmatch(r"[A-Za-z0-9-]+_" + view.lower(), n) for n in names):
            raise ValueError(f"Invalid sequence name in {path}")
        duplicates = {n: c for n, c in Counter(names).items() if c > 1}
        expected = config["views"][view]
        if (len(names) != expected["entries"] or len(set(names)) != expected["unique_sequences"]
                or duplicates != expected["duplicates"]):
            raise ValueError(f"Sequence list does not match the {config['name']} protocol: {view}")
        lists[view] = names
    if [n.removesuffix("_uav") for n in lists["UAV"]] != [n.removesuffix("_gro") for n in lists["GRO"]]:
        raise ValueError("UAV and GRO sequence lists are not paired")
    return config, lists


def evaluate_view(root: Path, results_dir: Path, names: list[str], view: str) -> dict:
    cache = {}
    for name in dict.fromkeys(names):
        anno = load_rects(root / "annos" / f"{name}.txt")
        if not np.isfinite(anno).all():
            raise ValueError(f"Non-finite GT: {name}")
        try:
            pred = load_rects(find_result(results_dir, name, view))
            success, precision, repaired, trimmed = sequence_curves(pred, anno)
        except (OSError, ValueError) as exc:
            raise ValueError(f"{name}: {exc}") from exc
        cache[name] = (success, precision, len(anno), repaired, trimmed)
    # The validated configuration contains each of the 45 test sequences once.
    success = np.mean([cache[n][0] for n in names], axis=0)
    precision = np.mean([cache[n][1] for n in names], axis=0)
    return {
        "entries": len(names),
        "unique_sequences": len(cache),
        "duplicates": {n: c for n, c in Counter(names).items() if c > 1},
        "unique_frames": sum(x[2] for x in cache.values()),
        "weighted_frames": sum(cache[n][2] for n in names),
        "repaired_prediction_rows": sum(x[3] for x in cache.values()),
        "trimmed_prediction_rows": sum(x[4] for x in cache.values()),
        "PR": float(precision[20]),
        "SR": float(success.mean()),
        "precision_curve": precision.tolist(),
        "success_curve": success.tolist(),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", required=True, type=Path, help="Directory containing extracted prediction TXT files")
    parser.add_argument("--view", choices=("both", "UAV", "GRO"), default="both")
    parser.add_argument("--json", type=Path, help="Optional output report (refuses to overwrite an existing file)")
    parser.add_argument("--verify-reference", action="store_true", help="Check metrics against the separately released VL-UniTrack final results")
    args = parser.parse_args(argv)
    try:
        if not args.results.is_dir():
            raise ValueError(f"Not a prediction directory: {args.results}")
        if args.json is not None and args.json.exists():
            raise ValueError(f"Report already exists: {args.json}")
        config, lists = load_protocol(ROOT)
        print(config["name"])
        print(config["description"])
        report = {"protocol": config["id"], "views": {}}
        views = ("UAV", "GRO") if args.view == "both" else (args.view,)
        for view in views:
            result = evaluate_view(ROOT, args.results, lists[view], view)
            report["views"][view] = result
            print(f"{view}: PR={result['PR']:.6f}  SR={result['SR']:.6f}  "
                  f"entries={result['entries']}  unique_sequences={result['unique_sequences']}")
            if result["duplicates"]:
                print("  Repeated entries: " + ", ".join(f"{n} x{c}" for n, c in result["duplicates"].items()))
            if result["repaired_prediction_rows"] or result["trimmed_prediction_rows"]:
                print(f"  WARNING: repaired={result['repaired_prediction_rows']}, "
                      f"trimmed={result['trimmed_prediction_rows']} prediction rows", file=sys.stderr)
        if len(views) == 2:
            report["average"] = {m: float(np.mean([report["views"][v][m] for v in views])) for m in ("PR", "SR")}
            print(f"Average: PR={report['average']['PR']:.6f}  SR={report['average']['SR']:.6f}")
        if args.verify_reference:
            for view in views:
                for metric in ("PR", "SR"):
                    actual = report["views"][view][metric]
                    expected = config["reference_metrics"][view][metric]
                    if abs(actual - expected) > 1e-10:
                        raise ValueError(f"Reference mismatch: {view} {metric}={actual:.12f}, expected {expected:.12f}")
            print("Reference verification: PASS")
        if args.json is not None:
            args.json.parent.mkdir(parents=True, exist_ok=True)
            with args.json.open("x", encoding="utf-8") as handle:
                json.dump(report, handle, indent=2, allow_nan=False)
                handle.write("\n")
        return 0
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
